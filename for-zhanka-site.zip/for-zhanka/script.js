(function () {
  "use strict";

  var D = window.SITE || {};
  document.documentElement.classList.remove("no-js");

  /* ---------- помощники ---------- */
  function $(sel, root) { return (root || document).querySelector(sel); }
  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }
  function paragraphs(text) {
    return String(text || "").split(/\n{2,}/).map(function (p) {
      return "<p>" + esc(p).replace(/\n/g, "<br>") + "</p>";
    }).join("");
  }
  function plural(n, forms) {
    var a = Math.abs(n) % 100, b = a % 10;
    if (a > 10 && a < 20) return forms[2];
    if (b > 1 && b < 5) return forms[1];
    if (b === 1) return forms[0];
    return forms[2];
  }
  function parseDate(str) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(str || "");
    return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null;
  }
  function today() { var t = new Date(); return new Date(t.getFullYear(), t.getMonth(), t.getDate()); }
  function daysBetween(a, b) { return Math.round((b - a) / 86400000); }
  function fmtDate(d) {
    return d.toLocaleDateString("ru-RU", { day: "numeric", month: "long", year: "numeric" }).replace(/\s*г\.?$/, "");
  }
  function store(key, val) {
    try {
      if (val === undefined) return JSON.parse(localStorage.getItem(key) || "null");
      localStorage.setItem(key, JSON.stringify(val));
    } catch (e) { /* хранилище недоступно — не страшно */ }
    return null;
  }

  /* ---------- счётчики ---------- */
  function renderCounters() {
    var start = parseDate(D.start), now = today();
    if (start) {
      var days = Math.max(0, daysBetween(start, now));
      $("[data-days]").textContent = String(days);
      $("[data-days-label]").textContent = plural(days, ["день вместе", "дня вместе", "дней вместе"]);

      var months = (now.getFullYear() - start.getFullYear()) * 12 + now.getMonth() - start.getMonth();
      var anchor = new Date(start.getFullYear(), start.getMonth() + months, start.getDate());
      if (anchor > now) { months -= 1; anchor = new Date(start.getFullYear(), start.getMonth() + months, start.getDate()); }
      var rest = daysBetween(anchor, now);
      var txt = months + " " + plural(months, ["месяц", "месяца", "месяцев"]);
      if (rest > 0) txt += " " + rest + " " + plural(rest, ["день", "дня", "дней"]);
      $("[data-months]").textContent = txt;
      $("[data-months]").style.fontSize = "clamp(1.3rem, 3vw, 1.9rem)";

      var next = new Date(now.getFullYear(), start.getMonth(), start.getDate());
      if (next <= now) next = new Date(now.getFullYear() + 1, start.getMonth(), start.getDate());
      var left = daysBetween(now, next);
      $("[data-anniv]").textContent = "До нашей первой годовщины, " + fmtDate(next) + ": " +
        left + " " + plural(left, ["день", "дня", "дней"]) + ".";
    }

    var meet = parseDate(D.nextMeeting);
    var nEl = $("[data-next]"), lEl = $("[data-next-label]");
    if (meet) {
      var d = daysBetween(now, meet);
      if (d > 0) {
        nEl.textContent = String(d);
        lEl.textContent = plural(d, ["день до встречи", "дня до встречи", "дней до встречи"]);
      } else if (d === 0) {
        nEl.textContent = "сегодня!";
        lEl.textContent = "мы встречаемся";
      } else {
        nEl.textContent = "уже";
        lEl.textContent = "встретились";
      }
    } else {
      nEl.textContent = "?";
      lEl.textContent = "до встречи: весна или лето";
    }
  }

  /* ---------- история ---------- */
  function renderStory() {
    var list = $("[data-story]");
    list.innerHTML = (D.story || []).map(function (s) {
      var photo = s.photo ? '<img src="' + esc(s.photo) + '" alt="' + esc(s.title) + '" loading="lazy">' : "";
      return '<li class="story-item reveal"><div class="story-card' + (photo ? " has-photo" : "") + '">' +
        "<div><span class=\"story-tag\">" + esc(s.tag) + "</span><h3>" + esc(s.title) + "</h3><p>" + esc(s.text) + "</p></div>" +
        photo + "</div></li>";
    }).join("");
    list.querySelectorAll(".story-card img").forEach(function (img) {
      img.addEventListener("error", function () {
        var card = img.closest(".story-card");
        img.remove();
        if (card) card.classList.remove("has-photo");
      });
    });
  }

  /* ---------- фото ---------- */
  function renderPhotos() {
    var items = D.photos || [];
    var section = $("[data-photos-section]"), wall = $("[data-photos]");
    if (!items.length) return;
    section.hidden = false;
    wall.innerHTML = items.map(function (p) {
      var cap = [p.caption, p.date].filter(Boolean).join(" · ");
      return '<figure class="polaroid"><img src="' + esc(p.file) + '" alt="' + esc(cap || "фото") + '" loading="lazy">' +
        "<figcaption>" + esc(cap) + "</figcaption></figure>";
    }).join("");
    wall.querySelectorAll("img").forEach(function (img) {
      img.addEventListener("error", function () {
        var fig = img.closest("figure");
        if (fig) fig.remove();
        if (!wall.children.length) section.hidden = true;
      });
    });
  }

  /* ---------- фразы и голосовые ---------- */
  function renderQuotes() {
    var items = D.quotes || [];
    if (!items.length) return;
    $("[data-quotes-section]").hidden = false;
    $("[data-quotes]").innerHTML = items.map(function (q) {
      return '<div class="quote reveal">' + esc(q.text) + (q.date ? "<small>" + esc(q.date) + "</small>" : "") + "</div>";
    }).join("");
  }
  function renderVoices() {
    var items = D.voices || [];
    if (!items.length) return;
    $("[data-voices-section]").hidden = false;
    $("[data-voices]").innerHTML = items.map(function (v) {
      return '<div class="voice reveal"><p>' + esc(v.title || "Голосовое") + (v.date ? "<small>" + esc(v.date) + "</small>" : "") +
        '</p><audio controls preload="none" src="' + esc(v.file) + '"></audio></div>';
    }).join("");
  }

  /* ---------- словарик ---------- */
  function renderDict() {
    $("[data-dict]").innerHTML = (D.dictionary || []).map(function (w) {
      return '<li class="reveal"><div class="w">' + esc(w.word) + '</div><div class="m">= ' + esc(w.mean) +
        '</div><div class="n">' + esc(w.note) + "</div></li>";
    }).join("");
  }

  /* ---------- билеты ---------- */
  var TKEY = "for-zhanka-tickets-v1";

  function ticketHTML(t, st) {
    var used = st && st.used;
    var actions = "";
    if (used) {
      actions =
        '<div class="t-result"><p>' + esc(st.message) + '</p>' +
        '<button class="btn" type="button" data-copy>Скопировать сообщение</button>' +
        '<p class="t-done-note">Билет погашен. Отправьте это сообщение мне :)<br>' +
        '<button class="link-btn" type="button" data-reset>вернуть билет (если нажали случайно)</button></p></div>';
    } else if (t.type === "day") {
      actions = '<label for="in-' + esc(t.id) + '">Выберите день</label><input id="in-' + esc(t.id) +
        '" type="date" data-input><button class="btn" type="button" data-use>Использовать</button>';
    } else if (t.type === "custom") {
      actions = '<label for="in-' + esc(t.id) + '">Впишите своё желание</label><textarea id="in-' + esc(t.id) +
        '" data-input placeholder="например: ..."></textarea><button class="btn" type="button" data-use>Использовать</button>';
    } else {
      actions = '<button class="btn" type="button" data-use>Использовать</button>';
    }
    return '<article class="ticket t-ticket reveal' + (used ? " used" : "") + '" data-id="' + esc(t.id) + '">' +
      '<div class="ticket-main"><p class="ticket-small">билет № ' + esc(t.no) + "</p><h3>" + esc(t.title) +
      '</h3><p class="t-text">' + esc(t.text) + '</p><div class="t-actions">' + actions + "</div></div>" +
      '<div class="ticket-stub"><span class="stub-text">ADMIT ONE</span><span class="stub-num">№ ' + esc(t.no) + "</span></div>" +
      (used ? '<span class="t-stamp">ПОГАШЕН</span>' : "") + "</article>";
  }

  function copyText(text, btn) {
    function done() { if (btn) { var old = btn.textContent; btn.textContent = "Скопировано ✓"; setTimeout(function () { btn.textContent = old; }, 1800); } }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(done, fallback);
    } else { fallback(); }
    function fallback() {
      var ta = document.createElement("textarea");
      ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
      document.body.appendChild(ta); ta.select();
      try { document.execCommand("copy"); done(); } catch (e) { /* ничего */ }
      ta.remove();
    }
  }

  function renderTickets() {
    var box = $("[data-tickets]");
    var state = store(TKEY) || {};
    var tickets = D.tickets || [];

    box.innerHTML = tickets.map(function (t) { return ticketHTML(t, state[t.id]); }).join("");

    box.addEventListener("click", function (e) {
      var el = e.target.closest("article.t-ticket");
      if (!el) return;
      var t = tickets.filter(function (x) { return x.id === el.dataset.id; })[0];
      if (!t) return;
      var st = store(TKEY) || {};

      if (e.target.closest("[data-use]")) {
        var value = "";
        var input = $("[data-input]", el);
        if (t.type !== "fixed") {
          value = (input && input.value || "").trim();
          if (!value) { if (input) input.focus(); return; }
          if (t.type === "day") {
            var d = parseDate(value);
            if (d) value = fmtDate(d);
          }
        }
        var msg = String(t.message || "").replace("{value}", value);
        st[t.id] = { used: true, message: msg, at: Date.now() };
        store(TKEY, st);
        el.outerHTML = ticketHTML(t, st[t.id]).replace("reveal", "reveal in");
      } else if (e.target.closest("[data-copy]")) {
        copyText((st[t.id] || {}).message || "", e.target.closest("[data-copy]"));
      } else if (e.target.closest("[data-reset]")) {
        delete st[t.id];
        store(TKEY, st);
        el.outerHTML = ticketHTML(t, null).replace("reveal", "reveal in");
      }
    });
  }

  /* ---------- «открой, когда» ---------- */
  function renderEnvelopes() {
    var items = D.openWhen || [];
    var box = $("[data-envelopes]");
    var dlg = $("[data-dialog]");
    box.innerHTML = items.map(function (l, i) {
      return '<button class="envelope reveal" type="button" data-i="' + i + '"><small>открой, когда</small><strong>' +
        esc(l.when) + "</strong></button>";
    }).join("");

    box.addEventListener("click", function (e) {
      var b = e.target.closest(".envelope");
      if (!b) return;
      var l = items[+b.dataset.i];
      if (!l) return;
      $("[data-letter-when]").textContent = "открой, когда " + l.when;
      $("[data-letter-title]").textContent = l.title;
      $("[data-letter-text]").innerHTML = paragraphs(l.text);
      $("[data-letter-sign]").textContent = l.sign || "";
      if (typeof dlg.showModal === "function") dlg.showModal(); else dlg.setAttribute("open", "");
    });
    dlg.addEventListener("click", function (e) { if (e.target === dlg) dlg.close(); });
  }

  /* ---------- карта и планы ---------- */
  function renderDistance() {
    var c = D.cities || ["Ош", "Москва"];
    $("[data-city-a]").textContent = c[0];
    $("[data-city-b]").textContent = c[1];
    var km = Math.round((D.km || 0) / 10) * 10;
    if (km) $("[data-km]").textContent = "≈ " + km.toLocaleString("ru-RU") + " км";

    $("[data-plans]").innerHTML = (D.plans || []).map(function (p) {
      return '<li class="reveal' + (p.done ? " done" : "") + '"><span class="box">' + (p.done ? "✓" : "") +
        "</span><span>" + esc(p.text) + "</span></li>";
    }).join("");

    var meet = parseDate(D.nextMeeting);
    $("[data-plan-date]").textContent = meet
      ? "Дата встречи: " + fmtDate(meet) + "."
      : "Дата пока неизвестна: примерно весна или лето. Как только появится, здесь начнётся отсчёт.";
  }

  /* ---------- появление при прокрутке ---------- */
  function setupReveal() {
    var els = document.querySelectorAll(".reveal:not(.in)");
    if (!("IntersectionObserver" in window)) {
      els.forEach(function (el) { el.classList.add("in"); });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -6% 0px" });
    els.forEach(function (el) { io.observe(el); });
  }

  renderCounters();
  renderStory();
  renderPhotos();
  renderQuotes();
  renderVoices();
  renderDict();
  renderTickets();
  renderEnvelopes();
  renderDistance();
  setupReveal();
})();
